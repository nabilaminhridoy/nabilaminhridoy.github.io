import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { ThemeProvider } from "@/components/theme-provider";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Nabil Amin Hridoy - MERN Stack Developer",
  description: "Full-stack MERN developer specializing in scalable web applications, React, Node.js, and modern web technologies.",
  keywords: ["MERN Stack", "Full Stack Developer", "React", "Node.js", "MongoDB", "Express.js", "TypeScript", "Web Development"],
  authors: [{ name: "Nabil Amin Hridoy" }],
  openGraph: {
    title: "Nabil Amin Hridoy - MERN Stack Developer",
    description: "Full-stack developer building scalable web applications with modern technologies",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Nabil Amin Hridoy - MERN Stack Developer",
    description: "Full-stack developer building scalable web applications",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link 
          rel="stylesheet" 
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
          integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="
          crossOrigin="anonymous"
          referrerPolicy="no-referrer"
        />
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          {children}
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  );
}
